package com.isoftstone.service;

import java.util.List;

import com.iss.model.DeptInfo;
import com.iss.model.RegisterInfo;


public interface RegisterService {
	
	public List<DeptInfo> getDeptInfoList();

	public boolean addRegisterInfo(RegisterInfo info);

}
