package com.isoftstone.service;


import com.iss.model.CmPrescriotion;
import com.iss.model.Pagenation;


public interface PaymentService {
	
	public Pagenation<CmPrescriotion> getPage(String rid,int start,int end,int flag);//获取未支付的中药处方、西药处方、检查项目处方信息，用于收费查询展示(数据类型转换为中药处方的)
	
	public int settlement(String ids);	//收费操作，将选中的项目收费标记改为已收费
	
	public int refund(String ids);	//退费操作，对已收费进行退费并标记
	
}
