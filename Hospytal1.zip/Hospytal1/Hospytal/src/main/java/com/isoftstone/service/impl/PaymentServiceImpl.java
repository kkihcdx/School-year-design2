package com.isoftstone.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.isoftstone.dao.PaymentDao;
import com.isoftstone.dao.PreDao;
import com.isoftstone.service.PaymentService;
import com.iss.model.CheckItem;
import com.iss.model.CmPrescriotion;
import com.iss.model.Pagenation;
import com.iss.model.Payment;
import com.iss.model.WmPrescriotion;


@Service
public class PaymentServiceImpl implements PaymentService {
	
	@Autowired
	private PaymentDao paymentDao;	
	
	@Transactional
	public int settlement(String ids) {
		int a = this.paymentDao.updateCmpPon(ids);
		int b = this.paymentDao.updateWmpPon(ids);
		int c = this.paymentDao.updateCheckPon(ids);
		return a+b+c;
	}
	
	@Transactional
	public int refund(String ids) {
		int a = this.paymentDao.updateCmprefund(ids);
		int b = this.paymentDao.updateWmprefund(ids);
		int c = this.paymentDao.updateCheckrefund(ids);
		return a+b+c;
	}

	public Pagenation<CmPrescriotion> getPage(String rid,int start,int end,int flag) {
		//String rid = this.paymentDao.findRidByPID(pid);
		List<CmPrescriotion> alist=this.paymentDao.getCmp(rid,flag);
		List<WmPrescriotion> wmplist=this.paymentDao.getWmp(rid,flag);
		for (WmPrescriotion wmp : wmplist) {
			CmPrescriotion cmp=new CmPrescriotion(wmp.getWmi_id(),wmp.getWm_name(),wmp.getWm_price(),wmp.getWm_num(),wmp.getWm_total(),"","",0,0);
			alist.add(cmp);
		}
		List<CheckItem> cilist=this.paymentDao.getCheck(rid,flag);
		for (CheckItem ci : cilist) {
			CmPrescriotion cmp2=new CmPrescriotion(ci.getIi_id(),ci.getI_name(),ci.getI_price(),ci.getI_num(),ci.getI_total(),"","",0,0);
			alist.add(cmp2);
		}
		int total=alist.size();
		System.out.println(total);
		List<CmPrescriotion> rows=new ArrayList<CmPrescriotion>();
		if(total<end) {
			 rows=alist.subList(start, total);
		}else {
			 rows=alist.subList(start, end);
		}
		
		return new Pagenation<CmPrescriotion>(total, rows);
	}


}
