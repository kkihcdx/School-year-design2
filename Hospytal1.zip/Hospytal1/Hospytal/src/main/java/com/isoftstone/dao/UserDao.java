package com.isoftstone.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.isoftstone.entity.Users;


public interface UserDao {
	
	
	public List<Users> getAllUserList();
	
	public List<Users> searchUserList(@Param("realName")String realName,@Param("roleId")Integer roleId);
	
	public boolean insertUser(Users users);
	
	
	public boolean insertUserRole(@Param("userId") String userId,@Param("roleId") Integer roleId);
	
	
	public int deleteUser(String username);
	
	
	public int deleteUserRole(String username);
	

	public Users getUserByUserName(String userName);
	
	
	
	public boolean updateUser(Users users);
	
	
	public boolean updateUserRole(@Param("userId") String userId,@Param("roleId") Integer roleId);

}
