package com.isoftstone.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.isoftstone.service.DoctorService;
import com.isoftstone.service.PatientService;
import com.isoftstone.service.RegisterService;
import com.iss.model.DeptInfo;
import com.iss.model.DocInfo;
import com.iss.model.PatientInfo;
import com.iss.model.RegisterInfo;

@Controller
@RequestMapping("opreg")
public class PatientInfoControl {
	@Autowired
	private RegisterService registerService;
	
	@Autowired
	private DoctorService doctorService;
	
	@Autowired
	private PatientService patientService;
	
	@RequestMapping("loadOptRegistPage")
	public String loadOptRegistPage(Model model) {
		List<DeptInfo> list = new ArrayList<DeptInfo>();
		System.out.println("PatientInfoControl");
		list = registerService.getDeptInfoList();
//		System.out.println("list-size:" +list);
//		for(DeptInfo d : list){
//			System.out.println("department item:" + d.getDept_name() + d.getDept_adress());
//		}
		model.addAttribute("departments", list);
		return "/optRegister";
	}
	
    @RequestMapping("/selectDoctors")
    @ResponseBody
	public List<DocInfo> selectDoctors(String dept_id){
		List<DocInfo> list1=new ArrayList<DocInfo>();
		list1 = doctorService.getDoctorsList(dept_id);
		System.out.println(list1);
		return list1;
	}
	
	@RequestMapping("addPatient")
    @ResponseBody
	public PatientInfo addPatient(PatientInfo patientInfo){
		PatientInfo info= patientService.insertPatientInfo(patientInfo);
		return info;
	}
	
	
	@RequestMapping("selectPatients")
	@ResponseBody
	public List<PatientInfo> selectPatients(String patientName, String p_Id){
		List<PatientInfo> list1=new ArrayList<PatientInfo>();
		list1 = patientService.getPaientListByCardNumAndName(patientName,p_Id);
		System.out.println(patientName+";"+p_Id);
		System.out.println(list1);
		return list1;
	}
	
	
	@RequestMapping("selectPatientInfoById")
	@ResponseBody
	public PatientInfo selectPatientInfoById(String p_Id) {
		PatientInfo entity=this.patientService.getPatientInfoById(p_Id);
		System.out.println(entity);
		return entity;
	}
	
	@RequestMapping({"saveRegister"})
	@ResponseBody
	public boolean addRegisterInfo(String cardNum,Integer expenses_type,Integer diagnosis_type,Integer register_type,
			String dept_id,String doc_id,Double money) {
		RegisterInfo info = new RegisterInfo();
		
		PatientInfo patientInfo = new PatientInfo();
		patientInfo.setCardNum(cardNum);
		info.setPatientInfo(patientInfo);
		
		info.setExpenses_type(expenses_type);
		info.setDiagnosis_type(diagnosis_type);
		info.setRegister_type(register_type);
		
		DeptInfo deptInfo = new DeptInfo();
		deptInfo.setDept_id(dept_id);
		info.setDeptInfo(deptInfo);
		
		DocInfo docInfo= new DocInfo();
		docInfo.setDoc_id(doc_id);
		info.setDocInfo(docInfo);
		
		info.setMoney(money);
		
		System.out.println(cardNum+";"+expenses_type+";"+diagnosis_type+";"+register_type+";"+dept_id+";"+doc_id+";"+money+";");
		boolean flag=registerService.addRegisterInfo(info);
		
		return flag;
	}
}
