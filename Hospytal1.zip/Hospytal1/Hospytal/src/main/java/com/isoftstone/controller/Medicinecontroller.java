package com.isoftstone.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.isoftstone.service.MedicineService;


@Controller
@RequestMapping("med")
public class Medicinecontroller {
	
	@Autowired
	private MedicineService medicineService;
	
	@RequestMapping("/getChineseMedicineForSelect")
    @ResponseBody
    public List<Map<String, Object>> getChineseMedicineForSelect() {
        return this.medicineService.getChineseMedicineForSelect();
    }
	
	@RequestMapping("/getWesternMedicineForSelect")
    @ResponseBody
    public List<Map<String, Object>> getWesternMedicineForSelect() {
        return this.medicineService.getWesternMedicineForSelect();
    }
	
	@RequestMapping("/getInspectionItemForSelect")
    @ResponseBody
    public List<Map<String, Object>> getInspectionItemForSelect() {
        return this.medicineService.getInspectionItemForSelect();
    }

	
	

}
