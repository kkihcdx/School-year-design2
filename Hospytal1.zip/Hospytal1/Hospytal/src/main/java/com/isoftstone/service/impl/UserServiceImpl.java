package com.isoftstone.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftstone.dao.UserDao;
import com.isoftstone.entity.Users;
import com.isoftstone.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao dao;
	
	public List<Users> getAllUserList() {
		// TODO Auto-generated method stub
		List<Users> list = dao.getAllUserList(); 
		return list;
	}
	@Transactional
	public boolean inserUser(Users users) {
		if(users!=null && !"".equals(users.getUsername())) {
			users.setPassword("111111");
			boolean flag = dao.insertUser(users);
			if(flag) {
				if(users.getRole()!=null && users.getRole().getRoleId()!=null) {
					boolean flag1 = dao.insertUserRole(users.getUsername(),users.getRole().getRoleId());
					if(flag1) {
						return true;
					}
				}
			}
		}
		return false;
	}
	@Transactional
	public boolean deleteUser(String userName) {
		// TODO Auto-generated method stub
		if(!"".equals(userName)) {
			int flag = dao.deleteUser(userName);
			if(flag>0) {
				int flag1= dao.deleteUserRole(userName);
				if(flag1>0) {
						return true;
					}
			}
		}
		return false;
	}
	public Users getUserByUserName(String userName) {
		
		return dao.getUserByUserName(userName);
	}
	@Transactional
	public boolean updateUser(Users users) {
		if(users!=null && !"".equals(users.getUsername())) {
			boolean flag = dao.updateUser(users);
			if(flag) {
				if(users.getRole()!=null && !"".equals(users.getRole().getRoleId())) {
					boolean flag1 = dao.updateUserRole(users.getUsername(),users.getRole().getRoleId());
					if(flag1) {
						return true;
					}
				}
			}
		}
		return false;
	}
	
	public List<Users> searchUserList(String realName, Integer roleId) {
		return this.dao.searchUserList(realName, roleId);
	}

}
