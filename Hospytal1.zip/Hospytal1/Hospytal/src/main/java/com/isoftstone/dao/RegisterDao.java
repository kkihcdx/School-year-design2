package com.isoftstone.dao;

import java.util.List;

import com.iss.model.DeptInfo;
import com.iss.model.RegisterInfo;


public interface RegisterDao {
	
	public List<DeptInfo> getDeptInfoList();

	public void addRegisterInfo(RegisterInfo info);

}
