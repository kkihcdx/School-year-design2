package com.isoftstone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.isoftstone.entity.Menu;
import com.isoftstone.entity.Role;
import com.isoftstone.service.RoleService;


@Controller
@RequestMapping("role")
public class RoleController {

	@Autowired
	private RoleService service;
	
	@RequestMapping("roleList")
	public String getAllUsers(ModelMap modelMap) {
		
		List<Role> roleList = service.getAllRoleList();
		List<Menu> list = service.getAllMenuList();
		modelMap.addAttribute("roleList",roleList);
		modelMap.addAttribute("menuList",list);
		return "roleList";
			
	}
	
	@RequestMapping("insertRole")
	@ResponseBody
	public Role insertRole(String roleName){
			
		Role role = new Role();
		role.setRoleName(roleName);
		role = service.insertRole(role);
		return role;		
	}
	
	@RequestMapping("deleteRole")
	@ResponseBody
	 public boolean deleteRole(Integer roleId){
		boolean flag = service.deleteRole(roleId);
		return flag;
	}
	
	@RequestMapping("updateRole")
	@ResponseBody
	public boolean updateUser(String roleName,Integer roleId){
		Role role = new Role();
		role.setRoleId(roleId);
		role.setRoleName(roleName);
		boolean flag = service.updateRole(role);
		return flag;
	}
	
	@RequestMapping("getMenuListByRoleId")
	@ResponseBody
	public List<Menu> getMenuListByRoleId(Integer roleId) {
		List<Menu> menuList  = service.getMenusByRoleId(roleId);
		return menuList;
	}
	
	@RequestMapping("editRoleMenu")
	@ResponseBody
	public boolean editRoleMenu(Integer roleId,String menus) {
		String str = menus.endsWith("|")?menus.substring(0, menus.length()-1):menus;
		String[] str1 = str.split("\\|");
		Integer[] menuIds = new Integer[str1.length];
		for(int i=0;i<str1.length;i++) {
			menuIds[i] = Integer.valueOf(str1[i]);
		}
		boolean flag = service.editRoleMenu(roleId, menuIds);
		return flag;
		
	}
}
