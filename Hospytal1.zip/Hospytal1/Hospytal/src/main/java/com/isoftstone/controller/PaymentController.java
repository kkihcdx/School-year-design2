package com.isoftstone.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.isoftstone.service.PaymentService;
import com.iss.model.CmPrescriotion;
import com.iss.model.Pagenation;


@Controller
@RequestMapping("pay")
public class PaymentController {
	
	@Autowired
	private PaymentService paymentService;
	
	@RequestMapping("getPagebyId/{pid}")	//��ȡδ֧������Ŀ�˵�
	@ResponseBody
	public Pagenation<CmPrescriotion> getPagebyId(@PathVariable("pid") String pid,@RequestParam("page") int pageNum, 
		@RequestParam(value = "rows", defaultValue = "10") int pageSize ) {
	    return this.paymentService.getPage(pid, (pageNum-1) * pageSize, pageNum * pageSize,0); 
	    }
	
	@RequestMapping("getRefundbyId/{pid}")	//��ȡ��֧������δ�˷ѵ���Ŀ�˵�
	@ResponseBody
	public Pagenation<CmPrescriotion> getRefundbyId(@PathVariable("pid") String pid,@RequestParam("page") int pageNum, 
		@RequestParam(value = "rows", defaultValue = "10") int pageSize ) {
	    return this.paymentService.getPage(pid, (pageNum-1) * pageSize, pageNum * pageSize,1); 
	    }	
	
	@RequestMapping("settlement")	//�շѽ���
	@ResponseBody
	public Map<String, Object> settlement(@RequestParam("ids") String ids) {
		Map<String, Object> map = new HashMap<String, Object>();
		int  all= this.paymentService.settlement(ids);
		if (all > 0) {
			map.put("result", true);
			map.put("msg", "����ɹ�");
		} else {
			map.put("msg", "����ʧ��");
		}
		return map;
		}
	
	@RequestMapping("refund")	//�˷ѽ���
	@ResponseBody
	public Map<String, Object> refund(@RequestParam("ids") String ids) {
		Map<String, Object> map = new HashMap<String, Object>();
		int  a= this.paymentService.refund(ids);
		if (a > 0) {
			map.put("result", true);
			map.put("msg", "�˷ѳɹ����˷ѽ��Ϊ����");
		} else {
			map.put("msg", "�˷�ʧ��");
		}
		return map;
		}

}
