package com.isoftstone.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isoftstone.dao.RegisterDao;
import com.isoftstone.service.RegisterService;
import com.iss.model.DeptInfo;
import com.iss.model.RegisterInfo;

@Service
public class RegisterServiceImpl implements RegisterService{

	@Autowired
	private RegisterDao registerDao;
	
	public List<DeptInfo> getDeptInfoList() {
		System.out.println("RegisterServiceImpl");
		List<DeptInfo> list = registerDao.getDeptInfoList();
		System.out.println("list-size:" +list.size());
		return list;
	}

	public boolean addRegisterInfo(RegisterInfo info) {
		try {
			info.setRegister_id((UUID.randomUUID().toString()).substring(0, 7));
			info.setFlag(0);
			System.out.println(UUID.randomUUID().toString());
			registerDao.addRegisterInfo(info);
			//info.setDate();
			return true;
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

}
