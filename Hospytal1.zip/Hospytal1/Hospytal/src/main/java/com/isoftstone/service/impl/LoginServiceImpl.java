package com.isoftstone.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isoftstone.dao.LoginDao;
import com.isoftstone.entity.Menu;
import com.isoftstone.entity.Users;
import com.isoftstone.service.LoginService;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDao loginDao;

	public Users getUsersByUserNameAndPassword(String username, String password) {
		
		Users users= loginDao.getUsersByUserNameAndPassword(username, password);
		if(users!=null && !"".equals(users.getUsername())) {

			List<Menu> menuList = new ArrayList<Menu>();
			menuList = loginDao.getParentMenuList(users.getRole().getRoleId());
			
			for(Menu menu : menuList) {
				
				List<Menu> childrenMenuList = new ArrayList<Menu>();
				childrenMenuList = loginDao.getChildrenMenuListByParentAndRole(menu.getMenuId(),users.getRole().getRoleId());
				
				menu.setChildrenMenuList(childrenMenuList);
			}
			users.getRole().setMenuList(menuList);
			
		}
		return users;
	}
	

}
