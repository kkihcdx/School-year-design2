package com.isoftstone.controller;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.isoftstone.service.PreService;
import com.isoftstone.service.MedicineService;
import com.iss.model.CheckItem;
import com.iss.model.ChineseMedicine;
import com.iss.model.Pagenation;
import com.iss.model.WesternMedicine;
import com.iss.model.WmPrescriotion;
import com.iss.model.CmPrescriotion;
import com.iss.model.InspectionItem;


@Controller
@RequestMapping("pre")
public class Precontroller {
	
	 @Autowired
	 private PreService preService;
	 
	 @Autowired
	 private MedicineService medicineService;
	 
	 /*
	  * cmp.jsp  中药处方界面
	  */
	 //获取中药处方信息生成json
	 @RequestMapping("getCmpPage/{rid}")
	 @ResponseBody
	 public Pagenation<CmPrescriotion> getCmpPage(@PathVariable("rid") String rid,@RequestParam("page") int pageNum, 
			 	@RequestParam(value = "rows", defaultValue = "10") int pageSize) {
		 	int total = this.preService.getCount("cm_prescriotion",rid);
	        List<CmPrescriotion> rows = this.preService.getCmpPage(rid,(pageNum-1) * pageSize, pageSize);
	        return new Pagenation<CmPrescriotion>(total, rows); // 将 java 对象转成 JSON 对象
	    }
	 //根据id获取某一个中药处方信息，装入修改弹窗
	 @RequestMapping("getCmp/{id}")
	 @ResponseBody
	 public CmPrescriotion getCmp(@PathVariable("id") String id) {
			return preService.getCmp(id);
		}
	 //新增某一中药处方
	 @RequestMapping("insertCmp/{id}")
	 @ResponseBody
	 public Map<String, String> insertCmp(@PathVariable("id") String id,HttpServletRequest request) throws UnsupportedEncodingException {
			request.setCharacterEncoding("UTF-8");
			String cm_id = request.getParameter("cm_id");
			int cm_num = Integer.parseInt(request.getParameter("cm_num"));
			String cm_med_adv = request.getParameter("cm_med_adv");
			ChineseMedicine cm=this.medicineService.getChineseMedicineByCmId(cm_id);
			float total=cm.getCm_price()*cm_num;
			CmPrescriotion cmp= new CmPrescriotion("",cm.getCm_name(),cm.getCm_price(),cm_num,total,cm_med_adv,id,0,0);
			Map<String, String> map = new HashMap<String, String>();
			int a = this.preService.insertCmp(cmp);
			if (a > 0) {
				map.put("msg", "添加成功");
			} else {
				map.put("msg", "添加失败");
			}
			return map;
		}
	 //修改某一中药处方
	 @RequestMapping("updateCmp")
	 @ResponseBody
	 public Map<String, String> updateCmp(HttpServletRequest request) throws UnsupportedEncodingException {
			request.setCharacterEncoding("UTF-8");
			String cmi_id = request.getParameter("cmi_id");
			float cm_price=Float.parseFloat(request.getParameter("cm_price"));
			int cm_num = Integer.parseInt(request.getParameter("cm_num"));
			String cm_med_adv = request.getParameter("cm_med_adv");
			float cm_total=cm_price* cm_num;
			String sql="update cm_prescriotion set cm_num="+cm_num+",cm_total="+cm_total+",cm_med_adv='"+cm_med_adv+"' where cmi_id='"+cmi_id+"'";
			Map<String, String> map = new HashMap<String, String>();
			int a = this.preService.update(sql);
			if (a > 0) {
				map.put("msg", "修改成功");
			} else {
				map.put("msg", "修改失败");
			}
			return map;
		}
	 //删除某一中药处方
	 @RequestMapping("deleteCmp")
	 @ResponseBody
	 public Map<String, Object> deleteCmp(@RequestParam("ids") String ids) {
		    String sql="delete from cm_prescriotion where cmi_id in("+ids+")";
			Map<String, Object> map = new HashMap<String, Object>();
			int  a= this.preService.delete(sql);
			if (a > 0) {
				map.put("result", true);
				map.put("msg", "删除成功");
			} else {
				map.put("msg", "删除失败");
			}
			return map;
		}
	 
	 /*
	  * wmp.jsp  西药处方界面
	  */
	 //获取西药处方信息生成json
	 @RequestMapping("getWmpPage/{rid}")
	 @ResponseBody
	 public Pagenation<WmPrescriotion> getWmpPage(@PathVariable("rid") String rid,@RequestParam("page") int pageNum,
			 	@RequestParam(value = "rows", defaultValue = "10") int pageSize) {
		 	int total = this.preService.getCount("wm_prescriotion",rid);
	        List<WmPrescriotion> rows = this.preService.getWmpPage(rid,(pageNum-1) * pageSize, pageSize);
	        return new Pagenation<WmPrescriotion>(total, rows); // 将 java 对象转成 JSON 对象
	    }
	//根据id获取某一个西药处方信息，装入修改弹窗
	 @RequestMapping("getWmp/{rid}")
	 @ResponseBody
	 public WmPrescriotion getWmp(@PathVariable("rid") String rid) {
			return preService.getWmp(rid);
		}
	 //修改西药处方
	 @RequestMapping("updateWmp")
	 @ResponseBody
	 public Map<String, String> updateWmp(HttpServletRequest request) throws UnsupportedEncodingException {
			request.setCharacterEncoding("UTF-8");
			String wmi_id = request.getParameter("wmi_id");
			float wm_price=Float.parseFloat(request.getParameter("wm_price"));
			int wm_num = Integer.parseInt(request.getParameter("wm_num"));
			String wm_med_adv = request.getParameter("wm_med_adv");
			float wm_total=wm_price* wm_num;
			String sql="update wm_prescriotion set wm_num="+wm_num+",wm_total="+wm_total+",wm_med_adv='"+wm_med_adv+"' where wmi_id='"+wmi_id+"'";
			Map<String, String> map = new HashMap<String, String>();
			int a = this.preService.update(sql);
			if (a > 0) {
				map.put("msg", "修改成功");
			} else {
				map.put("msg", "修改失败");
			}
			return map;
		}
	 //新增西药处方
	 @RequestMapping("insertWmp/{rid}")
	 @ResponseBody
	 public Map<String, String> insertWmp(@PathVariable("rid") String rid,HttpServletRequest request) throws UnsupportedEncodingException {
			request.setCharacterEncoding("UTF-8");
			String wm_id = request.getParameter("wm_id");
			int wm_num = Integer.parseInt(request.getParameter("wm_num"));
			String wm_med_adv = request.getParameter("wm_med_adv");
			WesternMedicine wm=this.medicineService.getWesternMedicineByMmId(wm_id);
			float total=wm.getWm_price()*wm_num;
			WmPrescriotion wmp= new WmPrescriotion("",wm.getWm_name(),wm.getWm_price(),wm_num,total,wm_med_adv,rid,0,0);
			Map<String, String> map = new HashMap<String, String>();
			int a = this.preService.insertWmp(wmp);
			if (a > 0) {
				map.put("msg", "添加成功");
			} else {
				map.put("msg", "添加失败");
			}
			return map;
		}
	 //删除西药处方
	 @RequestMapping("deleteWmp")
	 @ResponseBody
	 public Map<String, Object> deleteWmp(@RequestParam("ids") String ids) {
		    String sql="delete from wm_prescriotion where wmi_id in("+ids+")";
			Map<String, Object> map = new HashMap<String, Object>();
			int  a= this.preService.delete(sql);
			if (a > 0) {
				map.put("result", true);
				map.put("msg", "删除成功");
			} else {
				map.put("msg", "删除失败");
			}
			return map;
		}
	 
	 /*
	  * 检查项目处方
	  */
	 //获取检查项目处方信息生成json
	 @RequestMapping("getCheckPage/{rid}")
	 @ResponseBody
	 public Pagenation<CheckItem> getCheckPage(@PathVariable("rid") String rid,@RequestParam("page") int pageNum,
			 		@RequestParam(value = "rows", defaultValue = "10") int pageSize) {
		 	int total = this.preService.getCount("check_item",rid);
	        List<CheckItem> rows = this.preService.getCheckPage(rid,(pageNum-1) * pageSize, pageSize);
	        return new Pagenation<CheckItem>(total, rows); // 将 java 对象转成 JSON 对象
	    }
	//根据id获取某一个检查项目处方信息，装入修改弹窗
	 @RequestMapping("getCheck/{rid}")
	 @ResponseBody
	 public CheckItem getCheck(@PathVariable("rid") String rid) {
			return preService.getCheck(rid);
		}
	 //新增检查项目处方
	 @RequestMapping("insertCheck/{rid}")
	 @ResponseBody
	 public Map<String, String> insertCheck(@PathVariable("rid") String rid,HttpServletRequest request) throws UnsupportedEncodingException {
			request.setCharacterEncoding("UTF-8");
			String i_id = request.getParameter("i_id");
			int i_num = Integer.parseInt(request.getParameter("i_num"));
			String i_med_adv = request.getParameter("i_med_adv");  
			InspectionItem ip=this.medicineService.getInspectionItemByItemId(i_id);
			System.out.println(i_id);
			System.out.println(ip);
			float total=ip.getI_price()*i_num;
			CheckItem checkItem= new CheckItem("",ip.getI_name(),ip.getI_price(),ip.getExe_dept(),ip.getI_dosage(),i_num,total,i_med_adv,rid,0,0);
			Map<String, String> map = new HashMap<String, String>();
			int a = this.preService.insertCheck(checkItem);
			if (a > 0) {
				map.put("msg", "添加成功");
			} else {
				map.put("msg", "添加失败");
			}
			return map;
		}
	 //修改检查项目处方
	 @RequestMapping("updateCheck")
	 @ResponseBody
	 public Map<String, String> updateCheck(HttpServletRequest request) throws UnsupportedEncodingException {
			request.setCharacterEncoding("UTF-8");
			String ii_id = request.getParameter("ii_id");
			float i_price=Float.parseFloat(request.getParameter("i_price"));
			int i_num = Integer.parseInt(request.getParameter("i_num"));
			String i_med_adv = request.getParameter("i_med_adv");
			float i_total=i_price* i_num;
			String sql="update check_item set i_num="+i_num+",i_total="+i_total+",i_med_adv='"+i_med_adv+"' where ii_id='"+ii_id+"'";
			Map<String, String> map = new HashMap<String, String>();
			int a = this.preService.update(sql);
			if (a > 0) {
				map.put("msg", "修改成功");
			} else {
				map.put("msg", "修改失败");
			}
			return map;
		}
	 //删除检查项目处方
	 @RequestMapping("deleteCheck")
	 @ResponseBody
	 public Map<String, Object> deleteCheck(@RequestParam("ids") String ids) {
		    String sql="delete from check_item where ii_id in("+ids+")";
			Map<String, Object> map = new HashMap<String, Object>();
			int  a= this.preService.delete(sql);
			if (a > 0) {
				map.put("result", true);
				map.put("msg", "删除成功");
			} else {
				map.put("msg", "删除失败");
			}
			return map;
		}

}
