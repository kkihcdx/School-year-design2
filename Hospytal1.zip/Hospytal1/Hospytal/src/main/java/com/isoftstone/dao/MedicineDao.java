package com.isoftstone.dao;

import java.util.List;
import java.util.Map;

import com.iss.model.ChineseMedicine;
import com.iss.model.InspectionItem;
import com.iss.model.WesternMedicine;



public interface MedicineDao {
	
	public List<Map<String, Object>> getChineseMedicineForSelect();
	
	public ChineseMedicine getChineseMedicineByCmId(String cm_id);
	
	public List<Map<String, Object>> getWesternMedicineForSelect();
	
	public WesternMedicine getWesternMedicineByCmId(String wm_id);
	
	public List<Map<String, Object>> getInspectionItemForSelect();	
	
	public InspectionItem getInspectionItemByItemId(String i_id);

}
