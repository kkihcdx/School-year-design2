package com.isoftstone.service;

import java.util.List;
import java.util.Map;

import com.iss.model.ChineseMedicine;
import com.iss.model.InspectionItem;
import com.iss.model.WesternMedicine;


/**
*药品管理(中药，希望，检查项)
*
*/

public interface MedicineService {
	
	
	
	
	public List<Map<String, Object>> getChineseMedicineForSelect();	//获取全部中药名称、ID，供医生选择
	
	public ChineseMedicine getChineseMedicineByCmId(String cm_id);	//获取某条中药信息，，可以将该内容赋值给中药处方
	
	public List<Map<String, Object>> getWesternMedicineForSelect();	//获取全部西药名称、ID，供医生选择
	
	public WesternMedicine getWesternMedicineByMmId(String wm_id);	//获取某条西药信息，可以将该内容赋值给西药处方
	
	public List<Map<String, Object>> getInspectionItemForSelect();	//获取全部检查项目名称、ID，供医生选择
	
	public InspectionItem getInspectionItemByItemId(String i_id);;	//获取某条检查项目信息，可以将该内容赋值给检查项目处方
	
	
	/**
	*通过西药id进行查询西药信息
	*/
	public List<WesternMedicine> getWesternMedicineList (String wm_name);
	
	
	
	
	/**
	*通过中药名称进行模糊查询西药信息
	*/
	public List<ChineseMedicine> getChineseMedicineList (String cm_name);
	
	
	
	/**
	* 通过检查项名称进行模糊查询医院检查项目。
	*/
	public List<InspectionItem> getInspectionItemList (String i_name);
	
	/**
	*获取某条检查项目信息，，可以将该内容赋值给病人检查项处方
	*/
	
	
	
	/**
	*获取多条西药信息，，可以将该内容赋值给西药处方
	*/
	public List<WesternMedicine> getWesternMedicineByWPmIds(String[] wm_ids);

	/**
	*选择多条中药信息
	*获取某条中药信息。，可以将该内容赋值给西药处方
	*/
	public List<ChineseMedicine> gctChineseMedicineByCmIds(String[] cm_ids);
	
	/**
	*选择多条检查项目
	*获取某条检查项目信息，，可以将该内容赋值给病人检查项处方
	*/
	public List<InspectionItem> getInspectionItemByItemIds(String[] i_ids);









}
