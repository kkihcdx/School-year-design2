package com.isoftstone.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.isoftstone.dao.MedicineDao;
import com.isoftstone.service.MedicineService;
import com.iss.model.ChineseMedicine;
import com.iss.model.InspectionItem;
import com.iss.model.WesternMedicine;




@Service
public class MedicineServiceImpt implements MedicineService {
	
	@Autowired
	private MedicineDao medicineDao;

	@Transactional
	public List<Map<String, Object>> getChineseMedicineForSelect() {
		
		return this.medicineDao.getChineseMedicineForSelect();
	}
	
	@Transactional
	public ChineseMedicine getChineseMedicineByCmId(String cm_id) {
		
		return this.medicineDao.getChineseMedicineByCmId(cm_id);
	}
	
	@Transactional
	public List<Map<String, Object>> getWesternMedicineForSelect() {
		
		return this.medicineDao.getWesternMedicineForSelect();
	}
	
	@Transactional
	public WesternMedicine getWesternMedicineByMmId(String wm_id) {
		
		return this.medicineDao.getWesternMedicineByCmId(wm_id);
	}
	
	@Transactional
	public List<Map<String, Object>> getInspectionItemForSelect() {
		
		return this.medicineDao.getInspectionItemForSelect();
	}
	
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public InspectionItem getInspectionItemByItemId(String i_id) {
		// TODO Auto-generated method stub
		return this.medicineDao.getInspectionItemByItemId(i_id);
	}

	@Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
	public List<WesternMedicine> getWesternMedicineList(String wm_name) {
		// TODO Auto-generated method stub
		return null;
	}

	

	public List<ChineseMedicine> getChineseMedicineList(String cm_name) {
		// TODO Auto-generated method stub
		return null;
	}

	

	public List<InspectionItem> getInspectionItemList(String i_name) {
		// TODO Auto-generated method stub
		return null;
	}

	

	public List<WesternMedicine> getWesternMedicineByWPmIds(String[] wm_ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ChineseMedicine> gctChineseMedicineByCmIds(String[] cm_ids) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<InspectionItem> getInspectionItemByItemIds(String[] i_ids) {
		// TODO Auto-generated method stub
		return null;
	}

	

	

}
