package com.isoftstone.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.iss.model.PatientInfo;


public interface PatientDao {
	
	public List<PatientInfo> getPaientListByCardNumAndName(@Param("name")String name,@Param("p_Id")String p_Id);

	public void insertPatientInfo(PatientInfo info);

	public PatientInfo getPatientInfoById(String p_Id);

}
