package com.isoftstone.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.isoftstone.entity.Menu;
import com.isoftstone.entity.Users;

public interface LoginDao {
	
	public Users getUsersByUserNameAndPassword(@Param("username") String username,@Param("password") String password);

		
	public List<Menu> getParentMenuList(Integer roleId);
		
	public List<Menu> getChildrenMenuListByParentAndRole(@Param("parentId")String parentId,@Param("roleId")Integer roleId);



}
