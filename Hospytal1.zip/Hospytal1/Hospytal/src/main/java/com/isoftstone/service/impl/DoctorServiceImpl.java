package com.isoftstone.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isoftstone.dao.DoctorDao;
import com.isoftstone.service.DoctorService;
import com.iss.model.DocInfo;

@Service
public class DoctorServiceImpl implements DoctorService {
	
	@Autowired
	private DoctorDao doctorDao;
	
	public List<DocInfo> getDoctorsList(String dept_id){
		List<DocInfo> list = doctorDao.getDoctorsList(dept_id);
		return list;
	}

}
