package com.isoftstone.service;

import java.util.List;

import com.isoftstone.entity.Menu;


public interface MenuService {

	public List<Menu> getParentMenuList();

	public List<Menu> getChildMenuListByParentId(Integer parentId);
	
	public Menu insertMenu(Menu menu);
	
	public Menu getMenuById(Integer menuId);
	
	public boolean updateMenu(Menu menu);
	
	public boolean deleteMenu(Integer menuId);
	
}
