package com.isoftstone.entity;

import java.util.List;

public class Menu {

	private String menuId;
	private String menuName;
	private String menuUrl;
	private Integer parentId;
	private List<Menu> childrenMenuList;
	
	public String getMenuId() {
		return menuId;
	}
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}
	public String getMenuName() {
		return menuName;
	}
	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}
	public String getMenuUrl() {
		return menuUrl;
	}
	public void setMenuUrl(String menuUrl) {
		this.menuUrl = menuUrl;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public List<Menu> getChildrenMenuList() {
		return childrenMenuList;
	}
	public void setChildrenMenuList(List<Menu> childrenMenuList) {
		this.childrenMenuList = childrenMenuList;
	}
	
}
