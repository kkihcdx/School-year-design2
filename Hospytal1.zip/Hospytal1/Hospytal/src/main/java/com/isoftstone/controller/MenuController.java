package com.isoftstone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.isoftstone.entity.Menu;
import com.isoftstone.service.MenuService;


@Controller
@RequestMapping("menu")
public class MenuController {

	@Autowired
	private MenuService service;
	
	@RequestMapping("menuList")
	public String getAllUsers(ModelMap modelMap) {
		
		List<Menu> list = service.getParentMenuList();
		modelMap.addAttribute("menuList",list);
		return "menuList";
			
	}
	
	@RequestMapping("getChildMenusByParentId")
	@ResponseBody
	public List<Menu> getChildMenusByParentId(Integer parentId) {
		
		List<Menu> list = service.getChildMenuListByParentId(parentId);
		return list;
			
	}
	
	@RequestMapping("insertMenu")
	@ResponseBody
	public Menu insertMenu(Integer parentId,String menuName,String menuUrl) {
		Menu menu = new Menu();
		if(parentId==null) {
			menu.setParentId(0);
		}else{
			menu.setParentId(parentId);
		}
		menu.setMenuName(menuName);
		menu.setMenuUrl(menuUrl);
		menu = service.insertMenu(menu);
		return menu;
	}
	
	@RequestMapping("getMenuById")
	@ResponseBody
	public Menu getMenuById(Integer menuId) {
		
		Menu menu = service.getMenuById(menuId);
		return menu;
			
	}
	
	@RequestMapping("updateMenu")
	@ResponseBody
	public boolean updateMenu(String menuId,String menuName,String menuUrl,Integer parentId){
		Menu menu = new Menu();
		if(parentId==null) {
			menu.setParentId(0);
		}else{
			menu.setParentId(parentId);
		}
		menu.setMenuId(menuId);
		menu.setMenuName(menuName);
		menu.setMenuUrl(menuUrl);
		boolean flag  = service.updateMenu(menu);
		return flag;
	}
	
	@RequestMapping("deleteMenu")
	@ResponseBody
	public boolean deleteMenu(Integer menuId){
		
		boolean flag  = service.deleteMenu(menuId);
		return flag;
	}
}
