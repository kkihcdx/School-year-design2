package com.isoftstone.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.iss.model.CheckItem;
import com.iss.model.CmPrescriotion;
import com.iss.model.WmPrescriotion;


public interface PreDao {
	
	
	public int getCount(@Param("table")String table,@Param("rid")String rid);
	
	public CmPrescriotion getCmp(String id);
	public WmPrescriotion getWmp(String id);
	public CheckItem getCheck(String id);
	
	public List<CmPrescriotion> getCmpPage(@Param("rid")String rid,@Param("start") int start, @Param("pageSize") int pageSize);
	public List<WmPrescriotion> getWmpPage(@Param("rid")String rid,@Param("start") int start, @Param("pageSize") int pageSize);
	public List<CheckItem> getCheckPage(@Param("rid")String rid,@Param("start") int start, @Param("pageSize") int pageSize);

    public int insertCmp(CmPrescriotion cmp);
    public int insertWmp(WmPrescriotion wmp);
    public int insertCheck(CheckItem check);

    public int update(@Param("sql")String sql);

    public int delete(@Param("sql")String sql);
    


}
