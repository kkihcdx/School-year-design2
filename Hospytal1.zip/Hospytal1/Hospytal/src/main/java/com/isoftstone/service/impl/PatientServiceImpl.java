package com.isoftstone.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isoftstone.dao.PatientDao;
import com.isoftstone.service.PatientService;
import com.iss.model.PatientInfo;

@Service
public class PatientServiceImpl implements PatientService {
	
	@Autowired
	private PatientDao patientDao;
	
	public List<PatientInfo> getPaientListByCardNumAndName(String name,String cardNum) {
		List<PatientInfo> list = patientDao.getPaientListByCardNumAndName(name,cardNum);
		return list;
	}

	public PatientInfo insertPatientInfo(PatientInfo info) {
		patientDao.insertPatientInfo(info);
		return info;
	}

	public PatientInfo getPatientInfoById(String p_Id) {
		return patientDao.getPatientInfoById(p_Id);
	}
	
	

}
