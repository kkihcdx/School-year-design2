package com.isoftstone.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.isoftstone.dao.PreDao;
import com.isoftstone.service.PreService;
import com.iss.model.CheckItem;
import com.iss.model.CmPrescriotion;
import com.iss.model.WmPrescriotion;




@Service
public class PreServiceimpl implements PreService {
	
	@Autowired
	private PreDao preDao;

	/*
	 * ��ҩ/��ҩ/�����Ŀ
	 */
	@Transactional
	public int getCount(String tableName,String rid) {
		
		return this.preDao.getCount(tableName,rid);//���ظùҺ�ID�µ�ĳһ���͵Ĵ�������
	}
	
	@Transactional
	public int update(String sql) {
		
		return this.preDao.update(sql);
	}


	@Transactional
	public int delete(String sql) {	
		
		return this.preDao.delete(sql);
	}
	
	/*
	 * ��ҩ
	 */
	@Transactional
	public List<CmPrescriotion> getCmpPage(String rid,int start, int pageSize) {
		
		return this.preDao.getCmpPage(rid,start, pageSize);
	}
	
	@Transactional
	public CmPrescriotion getCmp(String id) {
		
		return this.preDao.getCmp(id);
	}
	
	@Transactional
	public int insertCmp(CmPrescriotion cmp) {
		
		return this.preDao.insertCmp(cmp);
	}
	
	
	/*
	 * ��ҩ
	 */
	@Transactional
	public List<WmPrescriotion> getWmpPage(String rid,int start, int pageSize) {
		
		return this.preDao.getWmpPage(rid,start, pageSize);
	}
	
	@Transactional
	public WmPrescriotion getWmp(String id) {
		
		return this.preDao.getWmp(id);
	}
	
	@Transactional
	public int insertWmp(WmPrescriotion wmp) {
		
		return this.preDao.insertWmp(wmp);
	}
	
	/*
	 * �����Ŀ
	 */

	public List<CheckItem> getCheckPage(String rid,int start, int pageSize) {
		
		return this.preDao.getCheckPage(rid,start, pageSize);
	}

	public CheckItem getCheck(String id) {
		
		return this.preDao.getCheck(id);
	}

	public int insertCheck(CheckItem check) {
		
		return this.preDao.insertCheck(check);
	}
	
	



}
