package com.isoftstone.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftstone.dao.LoginDao;
import com.isoftstone.dao.MenuDao;
import com.isoftstone.dao.RoleDao;
import com.isoftstone.entity.Menu;
import com.isoftstone.entity.Role;
import com.isoftstone.service.RoleService;


@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleDao dao;
	@Autowired
	private LoginDao loginDao;
	@Autowired
	private MenuDao menuDao;
	
	public List<Role> getAllRoleList() {
		// TODO Auto-generated method stub
		return dao.getAllRoleList();
	}

	public Role insertRole(Role role) {
		dao.insertRole(role);
		return role;
	}

	public boolean deleteRole(Integer roleId) {
		if(roleId!=null){
			boolean flag1 = dao.deleteRole(roleId);
			if(flag1) {
				dao.deleteRoleMenu(roleId);
				return true;
			}
			
		}
		return false;
	}

	public boolean updateRole(Role role) {
		if(role!=null && role.getRoleId()!=null) {
			boolean flag = dao.updateRole(role);
			return flag;
		}
		return false;
	}

	public List<Menu> getAllMenuList() {
		// TODO Auto-generated method stub
		/**
		 * 绗竴绉嶏紝鍏堟煡璇arentId=0鐨刴enu锛屽湪鏌ヨ璇enu涓嬪搴旂殑瀛愮被鑿滃崟銆�
		 * 绗簩绉嶏紝涓�璧锋煡鍑烘潵骞舵樉绀猴紝
		 */
		return menuDao.getAllMenuList();
	}

	public List<Menu> getMenusByRoleId(Integer roleId) {
		List<Menu> menuList = new ArrayList<Menu>();
		menuList = loginDao.getParentMenuList(roleId);
		
		for(Menu menu : menuList) {
			//for 寰幆杈撳嚭鎵�鏈夌埗绾ц彍鍗曪紝骞堕�氳繃鏌ヨ杈撳嚭璇ョ埗绾ц彍鍗曚笅瀵瑰簲鐨勫瓙鑿滃崟
			//鍗筹細parent_id=menu.getMenuId nd roleId=role.getRoleId
			List<Menu> childrenMenuList = new ArrayList<Menu>();
			childrenMenuList = loginDao.getChildrenMenuListByParentAndRole(menu.getMenuId(),roleId);
			// 灏嗚幏鍙栫殑瀛愮骇鑿滃崟鏀惧叆鐖剁骇鑿滃崟涓嬨�傚墠绔氨鍙互閫氳繃鐖剁骇鑿滃崟鍙栧搴旂殑瀛愮骇鑿滃崟
			menu.setChildrenMenuList(childrenMenuList);
		}
		return menuList;
	}

	@Transactional
	public boolean editRoleMenu(Integer roleId, Integer[] menuIds) {
		// TODO Auto-generated method stub
		try {
			dao.deleteRoleMenu(roleId);
			dao.insertRoleMenu(roleId, menuIds);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;	
		}
	}

}
