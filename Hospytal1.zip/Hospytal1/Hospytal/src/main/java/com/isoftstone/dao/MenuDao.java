package com.isoftstone.dao;

import java.util.List;

import com.isoftstone.entity.Menu;

public interface MenuDao {

	/**
	 * 查询所有的菜单信息,包括子菜单信息
	 * @return
	 */
	public List<Menu> getAllMenuList();	
	
	/**
	 * 获取所有父菜单信息
	 * @return
	 */
	public List<Menu> getParentMenuList();

	/**
	 * 根据父菜单信息，查询该父菜单对应的功能菜单信息
	 * @return
	 */
	public List<Menu> getChildMenuListByParentId(Integer parentId);
	
	public void insertMenu(Menu menu);
	
	
	public Menu getMenuById(Integer menuId);
	
	public boolean updateMenu(Menu menu);
	
	public boolean deleteMenu(Integer menuId);

}
