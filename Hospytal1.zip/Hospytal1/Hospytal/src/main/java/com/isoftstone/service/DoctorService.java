package com.isoftstone.service;

import java.util.List;

import com.iss.model.DocInfo;


public interface DoctorService {
	
	public List<DocInfo> getDoctorsList(String dept_id);

}
