package com.isoftstone.controller;

import java.io.UnsupportedEncodingException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.isoftstone.entity.Menu;
import com.isoftstone.entity.Users;
import com.isoftstone.service.DiagService;
import com.iss.model.DiagnosisInfo;

@Controller
@RequestMapping("diag")
public class DiagController {
	
	@Autowired
	private DiagService diagService;
	
	@RequestMapping("diagList")	//��ȡ���˲˵�
	public String getAllUsers(ModelMap modelMap,HttpSession httpSession) {
		Users users = (Users) httpSession.getAttribute("users");
		if ((users.getRole()).getRoleId()==1) {
			List<Menu> list = this.diagService.getPatientMenuList("");
			System.out.println(list);
			modelMap.addAttribute("diagList",list);
		}else {
			List<Menu> list = this.diagService.getPatientMenuList(users.getUsername());
			modelMap.addAttribute("diagList",list);
		}	
		return "diagList";
			
	}
	
	@RequestMapping("getPatient/{rid}") //�ڲ��˲˵�ѡ���ˣ�ͨ�����˹Һ�id��rid����ȡ���������Ϣ
	public String getPatient(@PathVariable("rid") String rid,HttpServletRequest request) {
		DiagnosisInfo diag=this.diagService.getDiagnosisInfoByRid(rid);
		HttpSession session = request.getSession();
		session.setAttribute("diag",diag);
		System.out.println(diag);
		return "diagnosisinfo";
		
	}
	
	@RequestMapping("updatediag/{rid}")	//¼�����²��������Ϣ
	@ResponseBody
	public Map<String, String> insertCmp(@PathVariable("rid") String rid,HttpServletRequest request) 
			throws UnsupportedEncodingException, ParseException {
		request.setCharacterEncoding("UTF-8");
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String time=request.getParameter("onset_date");
		java.util.Date utildate=format.parse(time);
		Date onset_date = new Date(utildate.getTime());
		String chief_complaint = request.getParameter("chief_complaint");
		String HPI = request.getParameter("HPI");
		String PH = request.getParameter("PH");
		String allergy_history = request.getParameter("allergy_history");
		String diagnosis = request.getParameter("diagnosis");
		String diagnosis_notes = request.getParameter("diagnosis_notes");
		String disposal_plan = request.getParameter("disposal_plan");
		DiagnosisInfo newDiag =new DiagnosisInfo("",0,0,rid,onset_date,chief_complaint,HPI,PH,allergy_history,diagnosis,diagnosis_notes,disposal_plan,0);
		System.out.println(newDiag);
		Map<String, String> map = new HashMap<String, String>();
		int a = this.diagService.updateDiagnosisInfo(newDiag);
		if (a > 0) {
			map.put("msg", "����ɹ�");
		} else {
			map.put("msg", "����ʧ��");
		}
		return map;
		}
	
	@RequestMapping("setpatientdiag/{rid}")	//��ȡ���˲˵�
	public String setpatientdiag(ModelMap modelMap,@PathVariable("rid") String rid) {
		int a=this.diagService.setpatientdiag(rid);
		return "diagnosisinfo";
			
	}

}
