package com.isoftstone.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.isoftstone.entity.Role;


public interface RoleDao {

	/**
	 * 获取所有角色信息
	 * @return
	 */
	public List<Role> getAllRoleList();
	
	/**
	 * 添加角色信息表sys_role
	 * @param role
	 */
	public Integer insertRole(Role role);
	/**
	 * 添加该角色对应的菜单权限
	 * @param roleId
	 * @param menuList
	 * @return
	 */
	
	public boolean insertRoleMenu(@Param("roleId") Integer roleId,@Param("menuIds") Integer[] menuIds);
	/**
	 * 删除角色信息表sys_user 中role_id=roleId的记录
	 * @param roleId
	 */
	public boolean deleteRole(Integer roleId);
	
	/**
	 * 删除角色对应的菜单信息关系表sys_role_menu中role_id=roleId的记录
	 * @param roleId   角色id
	 */
	public boolean deleteRoleMenu(Integer roleId);
	
	
	/**
	 * 修改角色信息表sys_role
	 * @param role
	 */
	public boolean updateRole(Role role);
	

}
