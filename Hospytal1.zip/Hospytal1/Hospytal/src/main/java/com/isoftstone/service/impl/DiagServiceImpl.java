package com.isoftstone.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.isoftstone.dao.DiagDao;
import com.isoftstone.entity.Menu;
import com.isoftstone.service.DiagService;
import com.iss.model.DiagnosisInfo;


@Service
public class DiagServiceImpl implements DiagService {
	
	@Autowired 
	private DiagDao diagDao;
	
	/*
	 * �����listת��ΪmenuList��ʾ�ڲ˵�����
	 */
	public List<Menu> getPatientMenuList(String uasename) {
		int a=this.diagDao.insertPatientToDiag();
		List<Menu> list2=new ArrayList<Menu>();
		List<DiagnosisInfo> list1=this.diagDao.getPatientMenuList(uasename);
		System.out.println(list1);
		for (DiagnosisInfo d : list1) {
			Menu menu=new Menu();
			menu.setMenuId(d.getRegister_id());
			if(d!=null&&d.getDia_or_not()==0) {
				menu.setMenuName(d.getP_name());
				menu.setMenuUrl("getPatient/");
			}else {
				menu.setMenuName(d.getP_name()+"(�Ѿ���)");
				menu.setMenuUrl("getPatient/");
			}
			list2.add(menu);
		}
		return list2;
	}
	
	@Transactional
	public DiagnosisInfo getDiagnosisInfoByRid(String id) {
		return this.diagDao.getDiagnosisInfoByRid(id);
	}

	public int updateDiagnosisInfo(DiagnosisInfo diagnosisInfo) {
		
		return this.diagDao.updateDiagnosisInfo(diagnosisInfo);
	}

	public int setpatientdiag(String rid) {
		
		return this.diagDao.setpatientdiag(rid);
	}

	

}
