package com.isoftstone.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isoftstone.dao.LoginDao;
import com.isoftstone.dao.MenuDao;
import com.isoftstone.dao.RoleDao;
import com.isoftstone.entity.Menu;
import com.isoftstone.entity.Role;
import com.isoftstone.service.MenuService;
import com.isoftstone.service.RoleService;


@Service
public class MenuServiceImpl implements MenuService {

	@Autowired
	private MenuDao menuDao;
	

	public List<Menu> getParentMenuList() {
		// TODO Auto-generated method stub
		return menuDao.getParentMenuList();
	}

	public List<Menu> getChildMenuListByParentId(Integer parentId) {
		
		List<Menu> childrenMenuList = new ArrayList<Menu>();
		childrenMenuList = menuDao.getChildMenuListByParentId(parentId);
		return childrenMenuList;
	}

	public Menu insertMenu(Menu menu) {
		menuDao.insertMenu(menu);
		return menu;
	}

	public Menu getMenuById(Integer menuId) {
		
		return menuDao.getMenuById(menuId);
	}

	public boolean updateMenu(Menu menu) {
		// TODO Auto-generated method stub
		boolean flag = menuDao.updateMenu(menu);
		return flag;
	}

	public boolean deleteMenu(Integer menuId) {
		boolean flag = menuDao.deleteMenu(menuId);
		return flag;
	}

	
}
