package com.isoftstone.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.isoftstone.entity.Role;
import com.isoftstone.entity.Users;
import com.isoftstone.service.RoleService;
import com.isoftstone.service.UserService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping({"users"})
public class UserController {
	@Autowired
	private UserService service;
	@Autowired
	private RoleService roleService;

	@RequestMapping({"userList"})
	public String getAllUsers(Model model) {
		PageHelper.startPage(1, 4);
		List userList = this.service.getAllUserList();
		List roleList = this.roleService.getAllRoleList();
		PageInfo page = new PageInfo(userList);
		model.addAttribute("page", page);
		System.out.println(page);
		model.addAttribute("roleList", roleList);
		return "userList";
	}

	@RequestMapping({"insertUser"})
	@ResponseBody
	public boolean inserUser(Users users) {
		System.out.println(users);
		boolean flag = this.service.inserUser(users);
		return flag;
	}

	@RequestMapping({"deleteUser"})
	@ResponseBody
	public boolean deleteUser(String username) {
		boolean flag = this.service.deleteUser(username);
		return flag;
	}

	@RequestMapping({"getUserByUserName"})
	@ResponseBody
	public Users getUserByUserName(String username) {
		Users user = this.service.getUserByUserName(username);
		return user;
	}

	@RequestMapping({"updateUser"})
	@ResponseBody
	public boolean updateUser(String username, String realName, Integer roleId) {
		Users users = new Users();
		users.setUsername(username);
		users.setRealName(realName);
		Role role = new Role();
		role.setRoleId(roleId);
		users.setRole(role);
		boolean flag = this.service.updateUser(users);
		return flag;
	}

	@RequestMapping({"searchUsers"})
	@ResponseBody
	public PageInfo<Users> searchUsers(String realName, Integer roleId, Integer pageNumber, Integer pageSize) {
		System.out.println(pageSize + ":::" + pageNumber);
		PageHelper.startPage(pageNumber.intValue(), pageSize.intValue());
		List users = this.service.searchUserList(realName, roleId);
		PageInfo page = new PageInfo(users);
		return page;
	}
}