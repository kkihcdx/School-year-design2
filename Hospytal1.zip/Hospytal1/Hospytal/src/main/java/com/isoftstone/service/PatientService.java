package com.isoftstone.service;

import java.util.List;

import com.iss.model.PatientInfo;

public interface PatientService {
	
	public List<PatientInfo> getPaientListByCardNumAndName(String name,String p_Id);
	
	public PatientInfo insertPatientInfo(PatientInfo info);

	public PatientInfo getPatientInfoById(String p_Id);


}
