package com.isoftstone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.isoftstone.entity.Users;
import com.isoftstone.service.LoginService;

@Controller
@SessionAttributes(value={"users","menuList"})
public class LoginController {
	
	@Autowired
	private LoginService service;
	
	@RequestMapping("index")
	public String index(){
		return "../../index";
	}
    /**
    denlu 
    */
	@RequestMapping("login")
	public String login(Model model,String username,String password){
		
		Users users = service.getUsersByUserNameAndPassword(username, password);
		if(users!=null) {
			model.addAttribute("users", users);
			model.addAttribute("menuList", users.getRole().getMenuList());
			return "main";	
		}
		return "redirect:index";
	}

}
