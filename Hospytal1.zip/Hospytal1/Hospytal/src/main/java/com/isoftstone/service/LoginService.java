package com.isoftstone.service;

import com.isoftstone.entity.Users;

public interface LoginService {
	/**
	 * 如果用户名密码正确，则查询用户信息
	 * ，用户信息包括该用户对应的角色信息，
	 * 以及该角色对应的菜单栏信息
	 * 
	 * @param username
	 * @param password
	 * @return users
	 */
	public Users getUsersByUserNameAndPassword(String username,String password);
}
