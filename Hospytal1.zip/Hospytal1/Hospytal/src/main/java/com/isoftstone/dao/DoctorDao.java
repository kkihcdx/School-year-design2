package com.isoftstone.dao;

import java.util.List;

import com.iss.model.DocInfo;

public interface DoctorDao {

	public List<DocInfo> getDoctorsList(String dept_id);

}
