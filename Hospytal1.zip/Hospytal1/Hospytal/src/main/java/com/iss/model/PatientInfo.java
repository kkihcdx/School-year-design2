package com.iss.model;

import java.util.Date;

public class PatientInfo {
	
	private String cardNum;
	private String p_name;
	private Integer p_sex;
	private Integer p_age;
	private Date p_birthday;
	private String p_habitation;
	private String p_tel;
	private String p_Id;
	
	public Integer getP_sex() {
		return p_sex;
	}
	public void setP_sex(Integer p_sex) {
		this.p_sex = p_sex;
	}
	public Integer getP_age() {
		return p_age;
	}
	public void setP_age(Integer p_age) {
		this.p_age = p_age;
	}
	
	public Date getP_birthday() {
		return p_birthday;
	}
	public void setP_birthday(Date p_birthday) {
		this.p_birthday = p_birthday;
	}
	public String getP_habitation() {
		return p_habitation;
	}
	public void setP_habitation(String p_habitation) {
		this.p_habitation = p_habitation;
	}
	public String getP_tel() {
		return p_tel;
	}
	public void setP_tel(String p_tel) {
		this.p_tel = p_tel;
	}
	public String getCardNum() {
		return cardNum;
	}
	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_Id() {
		return p_Id;
	}
	public void setP_Id(String p_Id) {
		this.p_Id = p_Id;
	}
	@Override
	public String toString() {
		return "PatientInfo [cardNum=" + cardNum + ", p_name=" + p_name + ", p_sex=" + p_sex + ", p_age=" + p_age
				+ ", p_birthday=" + p_birthday + ", p_habitation=" + p_habitation + ", p_tel=" + p_tel + ", p_Id="
				+ p_Id + "]";
	}
	

}
