package com.iss.model;

import java.util.Date;

public class RegisterInfo {//挂号信息
	
	private String register_id;
	private Integer expenses_type;
	private Integer diagnosis_type;
	private Integer register_type;
	private Double Money;
	private Date date;
	private Integer flag;
	
	private PatientInfo patientInfo;
	private DeptInfo deptInfo;
	private DocInfo docInfo;
	
	public String getRegister_id() {
		return register_id;
	}
	public void setRegister_id(String register_id) {
		this.register_id = register_id;
	}
	public Integer getExpenses_type() {
		return expenses_type;
	}
	public void setExpenses_type(Integer expenses_type) {
		this.expenses_type = expenses_type;
	}
	public Integer getDiagnosis_type() {
		return diagnosis_type;
	}
	public void setDiagnosis_type(Integer diagnosis_type) {
		this.diagnosis_type = diagnosis_type;
	}
	public Integer getRegister_type() {
		return register_type;
	}
	public void setRegister_type(Integer register_type) {
		this.register_type = register_type;
	}
	public Double getMoney() {
		return Money;
	}
	public void setMoney(Double money) {
		Money = money;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Integer getFlag() {
		return flag;
	}
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	public PatientInfo getPatientInfo() {
		return patientInfo;
	}
	public void setPatientInfo(PatientInfo patientInfo) {
		this.patientInfo = patientInfo;
	}
	public DeptInfo getDeptInfo() {
		return deptInfo;
	}
	public void setDeptInfo(DeptInfo deptInfo) {
		this.deptInfo = deptInfo;
	}
	public DocInfo getDocInfo() {
		return docInfo;
	}
	public void setDocInfo(DocInfo docInfo) {
		this.docInfo = docInfo;
	}
	@Override
	public String toString() {
		return "RegisterInfo [register_id=" + register_id + ", expenses_type=" + expenses_type + ", diagnosis_type="
				+ diagnosis_type + ", register_type=" + register_type + ", Money=" + Money + ", date=" + date
				+ ", falg=" + flag + ", patientInfo=" + patientInfo + ", deptInfo=" + deptInfo + ", docInfo=" + docInfo
				+ "]";
	}
	
	

}
