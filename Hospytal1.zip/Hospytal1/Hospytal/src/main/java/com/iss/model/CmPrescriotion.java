package com.iss.model;
public class CmPrescriotion {//中药处方
	private String cmi_id;
	private String cm_name;
	private float cm_price;
	private int cm_num;
	private float cm_total;
	private String cm_med_adv;
	private String register_id;
	private int pay_or_not;
	private int refund;
	
	public CmPrescriotion() {
		
	}
	
	public CmPrescriotion(String cmi_id, String cm_name, float cm_price, int cm_num, float cm_total, String cm_med_adv) {
		this.cmi_id = cmi_id;
		this.cm_name = cm_name;
		this.cm_price = cm_price;
		this.cm_num = cm_num;
		this.cm_total = cm_total;
		this.cm_med_adv = cm_med_adv;
	}
	
	public CmPrescriotion(String cmi_id, String cm_name, float cm_price, int cm_num, float cm_total, String cm_med_adv,
			String register_id, int pay_or_not, int refund) {
		this.cmi_id = cmi_id;
		this.cm_name = cm_name;
		this.cm_price = cm_price;
		this.cm_num = cm_num;
		this.cm_total = cm_total;
		this.cm_med_adv = cm_med_adv;
		this.register_id = register_id;
		this.pay_or_not = pay_or_not;
		this.refund = refund;
	}
	public String getCmi_id() {
		return cmi_id;
	}
	public void setCmi_id(String cmi_id) {
		this.cmi_id = cmi_id;
	}
	public String getCm_name() {
		return cm_name;
	}
	public void setCm_name(String cm_name) {
		this.cm_name = cm_name;
	}
	public float getCm_price() {
		return cm_price;
	}
	public void setCm_price(float cm_price) {
		this.cm_price = cm_price;
	}
	public int getCm_num() {
		return cm_num;
	}
	public void setCm_num(int cm_num) {
		this.cm_num = cm_num;
	}
	public float getCm_total() {
		return cm_total;
	}
	public void setCm_total(float cm_total) {
		this.cm_total = cm_total;
	}
	public String getCm_med_adv() {
		return cm_med_adv;
	}
	public void setCm_med_adv(String cm_med_adv) {
		this.cm_med_adv = cm_med_adv;
	}
	public String getRegister_id() {
		return register_id;
	}
	public void setRegister_id(String register_id) {
		this.register_id = register_id;
	}
	public int getPay_or_not() {
		return pay_or_not;
	}
	public void setPay_or_not(int pay_or_not) {
		this.pay_or_not = pay_or_not;
	}
	public int getRefund() {
		return refund;
	}
	public void setRefund(int refund) {
		this.refund = refund;
	}
	
	

	@Override
	public String toString() {
		return "cm_prescriotion [cmi_id=" + cmi_id + ", cm_name=" + cm_name + ", cm_price=" + cm_price + ", cm_num="
				+ cm_num + ", cm_total=" + cm_total + ", cm_med_adv=" + cm_med_adv + "]";
	}
	
	

}
