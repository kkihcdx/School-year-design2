package com.iss.model;

public class DocInfo {
	
	private String doc_id;
	private String doc_name;
	private int doc_sex;
	private String dept_id;
	
	public String getDoc_id() {
		return doc_id;
	}
	public void setDoc_id(String doc_id) {
		this.doc_id = doc_id;
	}
	public String getDoc_name() {
		return doc_name;
	}
	public void setDoc_name(String doc_name) {
		this.doc_name = doc_name;
	}
	public int getDoc_sex() {
		return doc_sex;
	}
	public void setDoc_sex(int doc_sex) {
		this.doc_sex = doc_sex;
	}
	public String getDept_id() {
		return dept_id;
	}
	public void setDept_id(String dept_id) {
		this.dept_id = dept_id;
	}
	
	

}
