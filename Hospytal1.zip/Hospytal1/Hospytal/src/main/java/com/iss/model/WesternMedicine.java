package com.iss.model;

import java.sql.Date;

public class WesternMedicine {//西药信息
	
	private String wm_id;
	private String wm_name;
	private float wm_price;
	private String wm_specifications;
	private String wm_usage;
	private String wm_dosage;
	private Date wm_Expiration_date;
	private String wm_druglotnumber;
	private String wm_Manufacturer;
	
	
	
	public WesternMedicine() {
	
	}
	public WesternMedicine(String wm_id, String wm_name, float wm_price, String wm_specifications, String wm_usage,
			String wm_dosage, Date wm_Expiration_date, String wm_druglotnumber, String wm_Manufacturer) {
		this.wm_id = wm_id;
		this.wm_name = wm_name;
		this.wm_price = wm_price;
		this.wm_specifications = wm_specifications;
		this.wm_usage = wm_usage;
		this.wm_dosage = wm_dosage;
		this.wm_Expiration_date = wm_Expiration_date;
		this.wm_druglotnumber = wm_druglotnumber;
		this.wm_Manufacturer = wm_Manufacturer;
	}
	public String getWm_id() {
		return wm_id;
	}
	public void setWm_id(String wm_id) {
		this.wm_id = wm_id;
	}
	public String getWm_name() {
		return wm_name;
	}
	public void setWm_name(String wm_name) {
		this.wm_name = wm_name;
	}
	public float getWm_price() {
		return wm_price;
	}
	public void setWm_price(float wm_price) {
		this.wm_price = wm_price;
	}
	public String getWm_specifications() {
		return wm_specifications;
	}
	public void setWm_specifications(String wm_specifications) {
		this.wm_specifications = wm_specifications;
	}
	public String getWm_usage() {
		return wm_usage;
	}
	public void setWm_usage(String wm_usage) {
		this.wm_usage = wm_usage;
	}
	public String getWm_dosage() {
		return wm_dosage;
	}
	public void setWm_dosage(String wm_dosage) {
		this.wm_dosage = wm_dosage;
	}
	public Date getWm_Expiration_date() {
		return wm_Expiration_date;
	}
	public void setWm_Expiration_date(Date wm_Expiration_date) {
		this.wm_Expiration_date = wm_Expiration_date;
	}
	public String getWm_druglotnumber() {
		return wm_druglotnumber;
	}
	public void setWm_druglotnumber(String wm_druglotnumber) {
		this.wm_druglotnumber = wm_druglotnumber;
	}
	public String getWm_Manufacturer() {
		return wm_Manufacturer;
	}
	public void setWm_Manufacturer(String wm_Manufacturer) {
		this.wm_Manufacturer = wm_Manufacturer;
	}
}
