package com.iss.model;

public class WmPrescriotion {//西药处方
	private String wmi_id;
	private String wm_name;
	private float wm_price;
	private int wm_num;
	private float wm_total;
	private String wm_med_adv;
	private String register_id;
	private int pay_or_not;
	private int refund;
	
	public WmPrescriotion(String wmi_id, String wm_name, float wm_price, int wm_num, float wm_total, String wm_med_adv,
			String register_id, int pay_or_not, int refund) {
		this.wmi_id = wmi_id;
		this.wm_name = wm_name;
		this.wm_price = wm_price;
		this.wm_num = wm_num;
		this.wm_total = wm_total;
		this.wm_med_adv = wm_med_adv;
		this.register_id = register_id;
		this.pay_or_not = pay_or_not;
		this.refund = refund;
	}
	public WmPrescriotion() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getWmi_id() {
		return wmi_id;
	}
	public void setWmi_id(String wmi_id) {
		this.wmi_id = wmi_id;
	}
	public String getWm_name() {
		return wm_name;
	}
	public void setWm_name(String wm_name) {
		this.wm_name = wm_name;
	}
	public float getWm_price() {
		return wm_price;
	}
	public void setWm_price(float wm_price) {
		this.wm_price = wm_price;
	}
	public int getWm_num() {
		return wm_num;
	}
	public void setWm_num(int wm_num) {
		this.wm_num = wm_num;
	}
	public float getWm_total() {
		return wm_total;
	}
	public void setWm_total(float wm_total) {
		this.wm_total = wm_total;
	}
	public String getWm_med_adv() {
		return wm_med_adv;
	}
	public void setWm_med_adv(String wm_med_adv) {
		this.wm_med_adv = wm_med_adv;
	}
	public String getRegister_id() {
		return register_id;
	}
	public void setRegister_id(String register_id) {
		this.register_id = register_id;
	}
	public int getPay_or_not() {
		return pay_or_not;
	}
	public void setPay_or_not(int pay_or_not) {
		this.pay_or_not = pay_or_not;
	}
	public int getRefund() {
		return refund;
	}
	public void setRefund(int refund) {
		this.refund = refund;
	}
	
	
}
