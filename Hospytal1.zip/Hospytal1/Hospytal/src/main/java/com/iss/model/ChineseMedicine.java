package com.iss.model;

import java.sql.Date;

public class ChineseMedicine {//中药信息
	private String cm_id;
	private String cm_name;
	private float cm_price;
	private String cm_specifications;
	private String cm_usage;
	private String cm_dosage;
	private Date cm_Expiration_date;
	private String cm_druglotnumber;
	private String cm_Manufacturer;
	
	public ChineseMedicine() {
		
	}
	
	public ChineseMedicine(String cm_id, String cm_name, float cm_price, String cm_specifications, String cm_usage,
			String cm_dosage, Date cm_Expiration_date, String cm_druglotnumber, String cm_Manufacturer) {
		this.cm_id = cm_id;
		this.cm_name = cm_name;
		this.cm_price = cm_price;
		this.cm_specifications = cm_specifications;
		this.cm_usage = cm_usage;
		this.cm_dosage = cm_dosage;
		this.cm_Expiration_date = cm_Expiration_date;
		this.cm_druglotnumber = cm_druglotnumber;
		this.cm_Manufacturer = cm_Manufacturer;
	}
	public String getCm_id() {
		return cm_id;
	}
	public void setCm_id(String cm_id) {
		this.cm_id = cm_id;
	}
	public String getCm_name() {
		return cm_name;
	}
	public void setCm_name(String cm_name) {
		this.cm_name = cm_name;
	}
	public float getCm_price() {
		return cm_price;
	}
	public void setCm_price(float cm_price) {
		this.cm_price = cm_price;
	}
	public String getCm_specifications() {
		return cm_specifications;
	}
	public void setCm_specifications(String cm_specifications) {
		this.cm_specifications = cm_specifications;
	}
	public String getCm_usage() {
		return cm_usage;
	}
	public void setCm_usage(String cm_usage) {
		this.cm_usage = cm_usage;
	}
	public String getCm_dosage() {
		return cm_dosage;
	}
	public void setCm_dosage(String cm_dosage) {
		this.cm_dosage = cm_dosage;
	}
	public Date getCm_Expiration_date() {
		return cm_Expiration_date;
	}
	public void setCm_Expiration_date(Date cm_Expiration_date) {
		this.cm_Expiration_date = cm_Expiration_date;
	}
	public String getCm_druglotnumber() {
		return cm_druglotnumber;
	}
	public void setCm_druglotnumber(String cm_druglotnumber) {
		this.cm_druglotnumber = cm_druglotnumber;
	}
	public String getCm_Manufacturer() {
		return cm_Manufacturer;
	}
	public void setCm_Manufacturer(String cm_Manufacturer) {
		this.cm_Manufacturer = cm_Manufacturer;
	}

	@Override
	public String toString() {
		return "Chinese_medicine [cm_id=" + cm_id + ", cm_name=" + cm_name + ", cm_price=" + cm_price
				+ ", cm_specifications=" + cm_specifications + ", cm_usage=" + cm_usage + ", cm_dosage=" + cm_dosage
				+ ", cm_Expiration_date=" + cm_Expiration_date + ", cm_druglotnumber=" + cm_druglotnumber
				+ ", cm_Manufacturer=" + cm_Manufacturer + "]";
	}
	
	
}
