package com.iss.model;


public class DeptInfo {
	private String dept_id;
	private String dept_name;
	private String dept_address;
	private String dept_introduction;
	
	public DeptInfo() {
		
	}
	
	public DeptInfo(String dept_id, String dept_name, String dept_address, String dept_introduction) {
		super();
		this.dept_id = dept_id;
		this.dept_name = dept_name;
		this.dept_address = dept_address;
		this.dept_introduction = dept_introduction;
	}
	public String getDept_id() {
		return dept_id;
	}
	public void setDept_id(String dept_id) {
		this.dept_id = dept_id;
	}
	public String getDept_name() {
		return dept_name;
	}
	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}
	public String getDept_address() {
		return dept_address;
	}
	public void setDept_address(String dept_address) {
		this.dept_address = dept_address;
	}
	public String getDept_introduction() {
		return dept_introduction;
	}
	public void setDept_introduction(String dept_introduction) {
		this.dept_introduction = dept_introduction;
	}
	
}
