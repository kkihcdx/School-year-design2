package com.iss.model;

public class CheckItem {//项目�?查处�?
	private String ii_id;
	private String i_name;
	private float i_price;
	private String exe_dept;
	private String i_dosage;
	private int i_num;
	private float i_total;
	private String i_med_adv;
	private String register_id;
	private int pay_or_not;
	private int refund;
	
	public CheckItem() {
		
	}
	
	public CheckItem(String ii_id, String i_name, float i_price, String exe_dept, String i_dosage, int i_num,
			float i_total, String i_med_adv, String register_id, int pay_or_not, int refund) {
		this.ii_id = ii_id;
		this.i_name = i_name;
		this.i_price = i_price;
		this.exe_dept = exe_dept;
		this.i_dosage = i_dosage;
		this.i_num = i_num;
		this.i_total = i_total;
		this.i_med_adv = i_med_adv;
		this.register_id = register_id;
		this.pay_or_not = pay_or_not;
		this.refund = refund;
	}
	public String getIi_id() {
		return ii_id;
	}
	public void setIi_id(String ii_id) {
		this.ii_id = ii_id;
	}
	public String getI_name() {
		return i_name;
	}
	public void setI_name(String i_name) {
		this.i_name = i_name;
	}
	public float getI_price() {
		return i_price;
	}
	public void setI_price(float i_price) {
		this.i_price = i_price;
	}
	public String getExe_dept() {
		return exe_dept;
	}
	public void setExe_dept(String exe_dept) {
		this.exe_dept = exe_dept;
	}
	public String getI_dosage() {
		return i_dosage;
	}
	public void setI_dosage(String i_dosage) {
		this.i_dosage = i_dosage;
	}
	public int getI_num() {
		return i_num;
	}
	public void setI_num(int i_num) {
		this.i_num = i_num;
	}
	public float getI_total() {
		return i_total;
	}
	public void setI_total(float i_total) {
		this.i_total = i_total;
	}
	public String getI_med_adv() {
		return i_med_adv;
	}
	public void setI_med_adv(String i_med_adv) {
		this.i_med_adv = i_med_adv;
	}
	public String getRegister_id() {
		return register_id;
	}
	public void setRegister_id(String register_id) {
		this.register_id = register_id;
	}
	public int getPay_or_not() {
		return pay_or_not;
	}
	public void setPay_or_not(int pay_or_not) {
		this.pay_or_not = pay_or_not;
	}
	public int getRefund() {
		return refund;
	}
	public void setRefund(int refund) {
		this.refund = refund;
	}
	
	
}
