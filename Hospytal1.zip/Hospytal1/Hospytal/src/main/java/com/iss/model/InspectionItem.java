package com.iss.model;

public class InspectionItem {
	private String i_id;
	private String i_name;
	private float i_price;
	private String exe_dept;
	private String i_dosage;
	
	public InspectionItem() {
		
	}
	
	public InspectionItem(String i_id, String i_name, float i_price, String exe_dept, String i_dosage) {
		this.i_id = i_id;
		this.i_name = i_name;
		this.i_price = i_price;
		this.exe_dept = exe_dept;
		this.i_dosage = i_dosage;
	}
	public String getI_id() {
		return i_id;
	}
	public void setI_id(String i_id) {
		this.i_id = i_id;
	}
	public String getI_name() {
		return i_name;
	}
	public void setI_name(String i_name) {
		this.i_name = i_name;
	}
	public float getI_price() {
		return i_price;
	}
	public void setI_price(float i_price) {
		this.i_price = i_price;
	}
	public String getExe_dept() {
		return exe_dept;
	}
	public void setExe_dept(String exe_dept) {
		this.exe_dept = exe_dept;
	}
	public String getI_dosage() {
		return i_dosage;
	}
	public void setI_dosage(String i_dosage) {
		this.i_dosage = i_dosage;
	}
	
	
}
