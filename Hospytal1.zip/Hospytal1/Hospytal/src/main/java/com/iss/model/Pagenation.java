package com.iss.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Pagenation<T> {
	private int pageNum;

	private int pageSize = 5;

	private int total;

	private List<T> rows = new ArrayList<T>();

	private Map<String, String> params = new HashMap<String, String>();

	public Pagenation() {
	}

	public Pagenation(int total, List<T> rows) {
		this.total = total;
		this.rows = rows;
	}

	public Pagenation(int pageNum, int pageSize, int total, List<T> rows) {
		this.pageNum = pageNum;
		this.pageSize = pageSize;
		this.total = total;
		this.rows = rows;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public List<T> getRows() {
		return rows;
	}

	public void setRows(List<T> rows) {
		this.rows = rows;
	}

	public Map<String, String> getParams() {
		return params;
	}

	public void setParams(Map<String, String> params) {
		this.params = params;
	}

}
