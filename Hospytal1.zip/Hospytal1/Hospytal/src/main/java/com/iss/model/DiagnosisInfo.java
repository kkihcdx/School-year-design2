package com.iss.model;

import java.sql.Date;

public class DiagnosisInfo {//诊断信息
	
	private String p_name;
	private int p_sex;
	private int p_age;
	private String register_id;
	private Date onset_date;
	private String chief_complaint;
	private String HPI;
	private String PH;
	private String allergy_history;
	private String diagnosis;
	private String diagnosis_notes;
	private String disposal_plan;
	private int dia_or_not;
	
	public DiagnosisInfo() {
		
	}
	
	public DiagnosisInfo(String p_name, int p_sex, int p_age, String register_id, Date onset_date,
			String chief_complaint, String hPI, String pH, String allergy_history, String diagnosis,
			String diagnosis_notes, String disposal_plan, int dia_or_not) {
		this.p_name = p_name;
		this.p_sex = p_sex;
		this.p_age = p_age;
		this.register_id = register_id;
		this.onset_date = onset_date;
		this.chief_complaint = chief_complaint;
		HPI = hPI;
		PH = pH;
		this.allergy_history = allergy_history;
		this.diagnosis = diagnosis;
		this.diagnosis_notes = diagnosis_notes;
		this.disposal_plan = disposal_plan;
		this.dia_or_not = dia_or_not;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public int getP_sex() {
		return p_sex;
	}
	public void setP_sex(int p_sex) {
		this.p_sex = p_sex;
	}
	public int getP_age() {
		return p_age;
	}
	public void setP_age(int p_age) {
		this.p_age = p_age;
	}
	public String getRegister_id() {
		return register_id;
	}
	public void setRegister_id(String register_id) {
		this.register_id = register_id;
	}
	public Date getOnset_date() {
		return onset_date;
	}
	public void setOnset_date(Date onset_date) {
		this.onset_date = onset_date;
	}
	public String getChief_complaint() {
		return chief_complaint;
	}
	public void setChief_complaint(String chief_complaint) {
		this.chief_complaint = chief_complaint;
	}
	public String getHPI() {
		return HPI;
	}
	public void setHPI(String hPI) {
		HPI = hPI;
	}
	public String getPH() {
		return PH;
	}
	public void setPH(String pH) {
		PH = pH;
	}
	public String getAllergy_history() {
		return allergy_history;
	}
	public void setAllergy_history(String allergy_history) {
		this.allergy_history = allergy_history;
	}
	public String getDiagnosis() {
		return diagnosis;
	}
	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}
	public String getDiagnosis_notes() {
		return diagnosis_notes;
	}
	public void setDiagnosis_notes(String diagnosis_notes) {
		this.diagnosis_notes = diagnosis_notes;
	}
	public String getDisposal_plan() {
		return disposal_plan;
	}
	public void setDisposal_plan(String disposal_plan) {
		this.disposal_plan = disposal_plan;
	}
	public int getDia_or_not() {
		return dia_or_not;
	}
	public void setDia_or_not(int dia_or_not) {
		this.dia_or_not = dia_or_not;
	}

	@Override
	public String toString() {
		return "DiagnosisInfo [p_name=" + p_name + ", p_sex=" + p_sex + ", p_age=" + p_age + ", register_id="
				+ register_id + ", onset_date=" + onset_date + ", chief_complaint=" + chief_complaint + ", HPI=" + HPI
				+ ", PH=" + PH + ", allergy_history=" + allergy_history + ", diagnosis=" + diagnosis
				+ ", diagnosis_notes=" + diagnosis_notes + ", disposal_plan=" + disposal_plan + ", dia_or_not="
				+ dia_or_not + "]";
	}
	
	

}
